CREATE OR REPLACE PROCEDURE updateStudent_performance(
    s_student_id VARCHAR2, 
    dataChange VARCHAR2, 
    selection NUMBER
) AS
BEGIN
    SAVEPOINT sav1;

    IF selection = 1 THEN
        UPDATE Student_performance 
        SET Semester_Name = dataChange 
        WHERE Student_ID = s_student_id;
    ELSIF selection = 2 THEN
        UPDATE Student_performance 
        SET Paper_ID = dataChange 
        WHERE Student_ID = s_student_id;
    ELSIF selection = 3 THEN
        UPDATE Student_performance 
        SET Paper_Name = dataChange 
        WHERE Student_ID = s_student_id;
    ELSIF selection = 4 THEN
        UPDATE Student_performance 
        SET Marks = dataChange 
        WHERE Student_ID = s_student_id;
    ELSE
        dbms_output.put_line('Invalid selection value: ' || selection);
        ROLLBACK TO sav1;
        RETURN;
    END IF;

    -- Check if rows were updated
    IF SQL%ROWCOUNT = 0 THEN
        dbms_output.put_line('Unable to perform UPDATE! Student ID: ' || s_student_id || ' not found.');
    ELSE
        COMMIT;
    END IF;

END;
/

CREATE OR REPLACE TRIGGER before_update_stu_pref
BEFORE UPDATE ON Student_performance
FOR EACH ROW
BEGIN
    -- Validate Marks
    IF :NEW.Marks < 0 OR :NEW.Marks > 100 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Marks must be between 0 and 100.');
    END IF;
END;
/

CREATE OR REPLACE TRIGGER after_update_stu_perf
AFTER UPDATE ON Student_performance
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('Student with ID ' || :NEW.Student_ID || ' updated.');
END;
/


-- Execute the procedure for updating Student Performance Info
ACCEPT s_student_id CHAR PROMPT 'Please enter Student ID: '
ACCEPT s_selection NUMBER PROMPT 'Please enter selection number 1-4 (1=SemesterName, 2=PaperID, 3=PaperName, 4=Marks): '
ACCEPT s_dataChange CHAR PROMPT 'Please enter change data: '

DECLARE 
    l_selection NUMBER := '&s_selection';
    l_studentID VARCHAR2(255) := '&s_student_id';
    l_dataChange VARCHAR2(255) := '&s_dataChange';

BEGIN
    updateStudent_performance(
        l_studentID, 
        l_dataChange, 
        l_selection
    );
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('An error occurred: ' || SQLERRM);
END;
/

-- Display updated data
SELECT * FROM Student_performance WHERE Student_ID = '&s_student_id';
/
