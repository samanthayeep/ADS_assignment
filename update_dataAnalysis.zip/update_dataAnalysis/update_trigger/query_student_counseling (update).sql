SET SERVEROUTPUT ON;

-- Create or replace the procedure for updating student counseling info
CREATE OR REPLACE PROCEDURE updateStudentCounseling(
    s_student_id VARCHAR2, 
    dataChange VARCHAR2, 
    selection NUMBER
) AS
BEGIN 
    SAVEPOINT sav1;

    IF selection = 1 THEN
        BEGIN
            UPDATE Student_counseling 
            SET DOA = TO_DATE(dataChange, 'MM/DD/YYYY') 
            WHERE Student_ID = s_student_id;
        END;
    ELSIF selection = 2 THEN  
        BEGIN
            UPDATE Student_counseling 
            SET DOB = TO_DATE(dataChange, 'MM/DD/YYYY') 
            WHERE Student_ID = s_student_id;
        END;
    ELSIF selection = 3 THEN
        BEGIN
            UPDATE Student_counseling 
            SET Department_Choices = dataChange 
            WHERE Student_ID = s_student_id;
        END;
    ELSIF selection = 4 THEN
        BEGIN
            UPDATE Student_counseling 
            SET Department_Admission = dataChange 
            WHERE Student_ID = s_student_id;
        END;
    ELSE 
        dbms_output.put_line('Invalid selection value: ' || selection);
        ROLLBACK TO sav1;
    END IF;

    -- Check if rows were updated
    IF SQL%ROWCOUNT = 0 THEN
        dbms_output.put_line('Unable to perform UPDATE! Student ID: ' || s_student_id || ' not found.');
    ELSE
        COMMIT;
    END IF;

END;
/

-- Trigger 
-- Before Update Trigger
CREATE OR REPLACE TRIGGER before_update_stu_counsel
BEFORE UPDATE ON Student_counseling
FOR EACH ROW
BEGIN
    -- Validate date format for DOA
    IF :NEW.DOA IS NOT NULL AND 
       TO_CHAR(TO_DATE(:NEW.DOA, 'DD/MM/YYYY'), 'DD/MM/YYYY') != :NEW.DOA THEN
        RAISE_APPLICATION_ERROR(-20001, 'Invalid date format for DOA. Please use DD/MM/YYYY format.');
    END IF;

    -- Validate date format for DOB
    IF :NEW.DOB IS NOT NULL AND 
       TO_CHAR(TO_DATE(:NEW.DOB, 'DD/MM/YYYY'), 'DD/MM/YYYY') != :NEW.DOB THEN
        RAISE_APPLICATION_ERROR(-20002, 'Invalid date format for DOB. Please use DD/MM/YYYY format.');
    END IF;

    -- Check if the DEPARTMENT_CHOICES exists
    IF :NEW.DEPARTMENT_CHOICES != :OLD.DEPARTMENT_CHOICES THEN
        DECLARE
            v_count INTEGER;
        BEGIN
            SELECT COUNT(*)
            INTO v_count
            FROM Department_info
            WHERE Department_Name = :NEW.DEPARTMENT_CHOICES;

            IF v_count = 0 THEN
                RAISE_APPLICATION_ERROR(-20003, 'The new Department_Choices does not exist.');
            END IF;
        END;
    END IF;

    -- Check if the DEPARTMENT_ADMISSION exists
    IF :NEW.DEPARTMENT_ADMISSION != :OLD.DEPARTMENT_ADMISSION THEN
        DECLARE
            v_count INTEGER;
        BEGIN
            SELECT COUNT(*)
            INTO v_count
            FROM Department_info
            WHERE Department_Name = :NEW.DEPARTMENT_ADMISSION;

            IF v_count = 0 THEN
                RAISE_APPLICATION_ERROR(-20004, 'The new Department_Admission does not exist.');
            END IF;
        END;
    END IF;
END;
/

-- After Update Trigger
CREATE OR REPLACE TRIGGER after_update_stu_counsel
AFTER UPDATE ON Student_counseling
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('Student with ID ' || :NEW.STUDENT_ID || ' updated.');
END;
/


-- Execute the procedure for updating Student Counseling Info
accept s_student_id char prompt 'Please enter Student ID: '
accept s_selection number prompt 'Please enter selection number 1-4 (1=DateOfAdmission, 2=DateOfBirth, 3=DepartmentChoices, 4=DepartmentAdmission): '
accept s_dataChange char prompt 'Please enter change data (for date use DD/MM/YYYY format): '

DECLARE 
    l_selection NUMBER := '&s_selection';
    l_studentID VARCHAR2(255) := '&s_student_id';
    l_dataChange VARCHAR2(255) := '&s_dataChange';

BEGIN
    updateStudentCounseling(
        l_studentID, 
        l_dataChange, 
        l_selection
    );
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('An error occurred: ' || SQLERRM);
END;
/

-- Display updated data
SELECT * FROM Student_counseling WHERE Student_ID = '&s_student_id';
/
