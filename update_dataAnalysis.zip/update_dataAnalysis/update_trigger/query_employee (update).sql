SET SERVEROUTPUT ON;

-- Update into employee_info
CREATE OR REPLACE PROCEDURE updateEmployeeInfo(
    s_employee_id VARCHAR2, 
    dataChange VARCHAR2, 
    selection NUMBER
) AS
BEGIN
    SAVEPOINT sav1;

    IF selection = 1 THEN 
        -- Update DATE_OF_BIRTH
        UPDATE Employee_info 
        SET DOB = TO_DATE(dataChange, 'DD/MM/YYYY') 
        WHERE EMPLOYEE_ID = s_employee_id;
    ELSIF selection = 2 THEN
        -- Update DATE_OF_UNIVERSITY_JOINING
        UPDATE Employee_info 
        SET DOJ = TO_DATE(dataChange, 'DD/MM/YYYY') 
        WHERE EMPLOYEE_ID = s_employee_id;
    ELSIF selection = 3 THEN
        -- Update Department_ID
        UPDATE Employee_info 
        SET Department_ID = dataChange 
        WHERE EMPLOYEE_ID = s_employee_id;
    ELSE 
        dbms_output.put_line('Invalid selection value: ' || selection);
        ROLLBACK TO sav1;
        RETURN;
    END IF;

    -- Check if rows were updated
    IF SQL%ROWCOUNT = 0 THEN
        dbms_output.put_line('Unable to perform UPDATE! Employee ID: ' || s_employee_id || ' not found.');
        ROLLBACK TO sav1;
    ELSE
        COMMIT;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('An error occurred: ' || SQLERRM);
        ROLLBACK TO sav1;
END;
/

-- Trigger 
-- Before Update Trigger
CREATE OR REPLACE TRIGGER before_update_employee
BEFORE UPDATE ON Employee_info
FOR EACH ROW
BEGIN
    -- Validate date format for DATE_OF_BIRTH
    IF :NEW.DOB IS NOT NULL AND 
       TO_CHAR(TO_DATE(:NEW.DOB, 'DD/MM/YYYY'), 'DD/MM/YYYY') != :NEW.DOB THEN
        RAISE_APPLICATION_ERROR(-20001, 'Invalid date format for DATE_OF_BIRTH. Please use DD/MM/YYYY format.');
    END IF;

    -- Validate date format for DATE_OF_UNIVERSITY_JOINING
    IF :NEW.DOJ IS NOT NULL AND 
       TO_CHAR(TO_DATE(:NEW.DOJ, 'DD/MM/YYYY'), 'DD/MM/YYYY') != :NEW.DOJ THEN
        RAISE_APPLICATION_ERROR(-20002, 'Invalid date format for DATE_OF_UNIVERSITY_JOINING. Please use DD/MM/YYYY format.');
    END IF;

    -- Check if the Department_ID exists in the Department_info
    IF :NEW.Department_ID != :OLD.Department_ID THEN
        DECLARE
            v_count INTEGER;
        BEGIN
            SELECT COUNT(*)
            INTO v_count
            FROM Department_info
            WHERE Department_ID = :NEW.Department_ID;

            IF v_count = 0 THEN
                RAISE_APPLICATION_ERROR(-20003, 'The new Department_ID does not exist in the Department_info table.');
            END IF;
        END;
    END IF;
END;
/

--After Update Trigger 
CREATE OR REPLACE TRIGGER after_update_employee
AFTER UPDATE ON Employee_info
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('Employee with ID ' || :NEW.EMPLOYEE_ID || ' updated.');
END;
/

-- Execute update Employee Info
accept s_employee_id char prompt 'Please enter Employee ID: '
accept s_selection number prompt 'Please enter selection number 1-3 (1=DateOfBirth, 2=DateOfUniversityJoining, 3=DepartmentID): '
accept s_dataChange char prompt 'Please enter change data (for date use DD/MM/YYYY format): ';

DECLARE 
    l_selection NUMBER := '&s_selection';
    l_employeeID VARCHAR2(255) := '&s_employee_id';
    l_dataChange VARCHAR2(255) := '&s_dataChange';

BEGIN
    updateEmployeeInfo(
        l_employeeID, 
        l_dataChange, 
        l_selection
    );
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line('An error occurred: ' || SQLERRM);
END;
/

-- display updated data
SELECT * FROM Employee_info WHERE EMPLOYEE_ID = '&s_employee_id';
/



