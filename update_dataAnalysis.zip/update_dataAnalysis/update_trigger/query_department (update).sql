SET SERVEROUTPUT ON;

-- Update into department_info
CREATE OR REPLACE PROCEDURE updateDepartmentInfo(
    s_department_id VARCHAR2, 
    dataChange VARCHAR2, 
    selection NUMBER
) AS
    
BEGIN
    SAVEPOINT sav1;

    IF selection = 1 THEN 
        UPDATE Department_info 
        SET department_name = dataChange 
        WHERE department_id = s_department_id;
    ELSIF selection = 2 THEN
        UPDATE Department_info 
        SET doe = TO_DATE(dataChange, 'DD/MM/YYYY') 
        WHERE department_id = s_department_id;
    ELSE
        dbms_output.put_line('Invalid selection value: ' || selection);
        ROLLBACK TO sav1;
        RETURN;
    END IF;

    -- Check if rows were updated
    IF SQL%ROWCOUNT = 0 THEN
        dbms_output.put_line('Unable to perform UPDATE! Department ID: ' || s_department_id || ' not found.');
    ELSE
        COMMIT;
    END IF;

END;
/

-- Trigger for Department info
-- BEFORE UPDATE Trigger:
CREATE OR REPLACE TRIGGER before_update_department
BEFORE UPDATE ON Department_info
FOR EACH ROW
BEGIN
    -- Ensure Department_Name not null
    IF :NEW.Department_Name IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'Department Name cannot be null.');
    END IF;

    -- Check date format
    IF TO_CHAR(TO_DATE(:NEW.doe, 'DD/MM/YYYY'), 'DD/MM/YYYY') != :NEW.doe THEN
        RAISE_APPLICATION_ERROR(-20002, 'Invalid date format. Please use DD/MM/YYYY format.');
    END IF;
END;
/

--After Update Trigger 
CREATE OR REPLACE TRIGGER after_update_department
AFTER UPDATE ON Department_info
FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('Department with ID ' || :NEW.DEPARTMENT_ID || ' updated.');
END;
/



-- Execute update Department Info
ACCEPT s_department_id CHAR PROMPT 'Please enter Department ID: ';
ACCEPT s_selection NUMBER PROMPT 'Please enter selection number 1-2 (1=DepartmentName, 2=DOE): ';
ACCEPT s_dataChange CHAR PROMPT 'Please enter change data (for date use DD/MM/YYYY format): ';

DECLARE 
    l_selection NUMBER := '&s_selection';
    l_departmentID VARCHAR2(255) := '&s_department_id';
    l_dataChange VARCHAR2(255) := '&s_dataChange';
BEGIN
    updateDepartmentInfo(
        l_departmentID, 
        l_dataChange, 
        l_selection
    );
END;
/


-- display update data
SELECT * FROM Department_info WHERE department_id = '&s_department_id';
