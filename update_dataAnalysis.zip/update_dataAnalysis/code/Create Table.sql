--connect to database--

CREATE USER assignment IDENTIFIED BY 1234;

GRANT CONNECT TO assignment;
GRANT CREATE SESSION, CREATE TABLE, UNLIMITED TABLESPACE TO assignment;


-- Step 1: Drop Existing Tables
DROP TABLE Department_info CASCADE CONSTRAINTS;
DROP TABLE Employee_info CASCADE CONSTRAINTS;
DROP TABLE Student_counseling CASCADE CONSTRAINTS;
DROP TABLE Student_performance CASCADE CONSTRAINTS;

-- Step 2: Create Tables without Primary Keys and Foreign Keys
CREATE TABLE Department_info (
    Department_ID VARCHAR2(20) NOT NULL,
    Department_Name VARCHAR2(100) NOT NULL,
    DOE DATE NOT NULL
);

CREATE TABLE Employee_info (
    Employee_ID VARCHAR2(20) NOT NULL,
    DOB DATE NOT NULL,
    DOJ DATE NOT NULL,
    Department_ID VARCHAR2(20) NOT NULL
);

CREATE TABLE Student_counseling (
    Student_ID VARCHAR2(20) NOT NULL,
    DOA DATE NOT NULL,
    DOB DATE NOT NULL,
    Department_Choices VARCHAR2(20) NOT NULL,
    Department_Admission VARCHAR2(20) NOT NULL
);

CREATE TABLE Student_performance (
    Student_ID VARCHAR2(20) NOT NULL,
    Semester_Name VARCHAR2(20) NOT NULL,
    Paper_ID VARCHAR2(20) NOT NULL,
    Paper_Name VARCHAR2(100) NOT NULL,
    Marks NUMBER NOT NULL
);

-- Step 3: Insert Data
-- Insert data into the tables here

--注： import student performance的时候， 有error的话check下右边target table column有没有match到（column definition那边)有时候会乱--

--接remove duplication的script---
