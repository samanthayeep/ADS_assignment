-- Step 4: Remove Duplicates
DELETE FROM Department_info
WHERE ROWID IN (
    SELECT ROWID
    FROM (
        SELECT ROWID, ROW_NUMBER() OVER (PARTITION BY Department_ID ORDER BY ROWID) AS rn
        FROM Department_info
    )
    WHERE rn > 1
);

DELETE FROM Employee_info
WHERE ROWID IN (
    SELECT ROWID
    FROM (
        SELECT ROWID, ROW_NUMBER() OVER (PARTITION BY Employee_ID ORDER BY ROWID) AS rn
        FROM Employee_info
    )
    WHERE rn > 1
);

DELETE FROM Student_counseling
WHERE ROWID IN (
    SELECT ROWID
    FROM (
        SELECT ROWID, ROW_NUMBER() OVER (PARTITION BY Student_ID ORDER BY ROWID) AS rn
        FROM Student_counseling
    )
    WHERE rn > 1
);

DELETE FROM Student_performance
WHERE ROWID IN (
    SELECT ROWID
    FROM (
        SELECT ROWID, ROW_NUMBER() OVER (PARTITION BY Student_ID, Semester_Name, Paper_ID ORDER BY ROWID) AS rn
        FROM Student_performance
    )
    WHERE rn > 1
);


-- Step 5: Add Primary Keys
ALTER TABLE Department_info
ADD CONSTRAINT pk_Department PRIMARY KEY (Department_ID);

ALTER TABLE Employee_info
ADD CONSTRAINT pk_Employee PRIMARY KEY (Employee_ID);

ALTER TABLE Student_counseling
ADD CONSTRAINT pk_Student_counseling PRIMARY KEY (Student_ID);

ALTER TABLE Student_performance
ADD CONSTRAINT pk_Student_performance PRIMARY KEY (Student_ID, Semester_Name, Paper_ID);


-- Step 6: Add Foreign Keys
ALTER TABLE Employee_info
ADD CONSTRAINT fk_Employee_Department FOREIGN KEY (Department_ID) REFERENCES Department_info (Department_ID);

ALTER TABLE Student_counseling
ADD CONSTRAINT fk_Student_Admission FOREIGN KEY (Department_Admission) REFERENCES Department_info (Department_ID);

ALTER TABLE Student_performance
ADD CONSTRAINT fk_Student_performance_Student FOREIGN KEY (Student_ID) REFERENCES Student_counseling (Student_ID);




--Index on Department_Name for faster searches--
CREATE INDEX IDX_Department_Name ON Department_info (Department_Name);


-- Foreign key index to improve joins with Department_Info
CREATE INDEX IDX_Employee_Department ON Employee_info (Department_ID);


-- Foreign key index to improve joins with Department_Info
CREATE INDEX IDX_Student_Department ON Student_counseling (Department_Admission);


-- Foreign key index to improve joins with Student_Counseling
CREATE INDEX IDX_Student_Performance_Couns ON Student_performance (Student_ID);
--------------------------------------------------------------------------------------------------------------------------------






-- Check primary keys
SELECT constraint_name, column_name
FROM all_cons_columns
WHERE table_name IN ('DEPARTMENT_INFO', 'EMPLOYEE_INFO', 'STUDENT_COUNSELING', 'STUDENT_PERFORMANCE')
AND constraint_name IN (
    SELECT constraint_name
    FROM all_constraints
    WHERE constraint_type = 'P'
    AND table_name IN ('DEPARTMENT_INFO', 'EMPLOYEE_INFO', 'STUDENT_COUNSELING', 'STUDENT_PERFORMANCE')
);


-- Check foreign keys
SELECT a.constraint_name, a.column_name, c_pk.table_name AS referenced_table, c_pk.column_name AS referenced_column
FROM all_cons_columns a
JOIN all_constraints c ON a.constraint_name = c.constraint_name
JOIN all_cons_columns c_pk ON c.r_constraint_name = c_pk.constraint_name
WHERE c.constraint_type = 'R'
AND a.table_name IN ('EMPLOYEE_INFO', 'STUDENT_COUNSELING', 'STUDENT_PERFORMANCE');
