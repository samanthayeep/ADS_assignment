--insert deleted data into new table for backup--

CREATE TABLE Department_info_Deleted (
    Department_ID VARCHAR2(20), 
    Department_Name VARCHAR2(100), 
    DOE DATE, 
    deleted_at TIMESTAMP
);


CREATE TABLE Employee_info_Deleted (
    Employee_ID VARCHAR2(20), 
    DOB DATE, 
    DOJ DATE, 
    Department_ID VARCHAR2(20), 
    deleted_at TIMESTAMP
);


CREATE TABLE Student_counseling_Deleted (
    Student_ID VARCHAR2(20), 
    DOA DATE, 
    DOB DATE, 
    Department_Choices VARCHAR2(20), 
    Department_Admission VARCHAR2(20), 
    deleted_at TIMESTAMP
);


CREATE TABLE Student_performance_Deleted (
    Student_ID VARCHAR2(20), 
    Semester_Name VARCHAR2(20), 
    Paper_ID VARCHAR2(20), 
    Paper_Name VARCHAR2(100), 
    Marks NUMBER, 
    deleted_at TIMESTAMP
);


CREATE OR REPLACE TRIGGER after_delete_department
AFTER DELETE ON Department_info 
FOR EACH ROW 
BEGIN 
    INSERT INTO Department_info_Deleted (
        Department_ID, Department_Name, DOE, deleted_at
    ) 
    VALUES (
        :OLD.Department_ID, :OLD.Department_Name, :OLD.DOE, SYSTIMESTAMP
    ); 
END; 
/


CREATE OR REPLACE TRIGGER after_delete_employee
AFTER DELETE ON Employee_info 
FOR EACH ROW 
BEGIN 
    INSERT INTO Employee_info_Deleted (
        Employee_ID, DOB, DOJ, Department_ID, deleted_at
    ) 
    VALUES (
        :OLD.Employee_ID, :OLD.DOB, :OLD.DOJ, :OLD.Department_ID, SYSTIMESTAMP
    ); 
END; 
/


CREATE OR REPLACE TRIGGER after_delete_stu_counsel
AFTER DELETE ON Student_counseling 
FOR EACH ROW 
BEGIN 
    INSERT INTO Student_counseling_Deleted (
        Student_ID, DOA, DOB, Department_Choices, Department_Admission, deleted_at
    ) 
    VALUES (
        :OLD.Student_ID, :OLD.DOA, :OLD.DOB, :OLD.Department_Choices, :OLD.Department_Admission, SYSTIMESTAMP
    ); 
END; 
/



CREATE OR REPLACE TRIGGER after_delete_stu_perf
AFTER DELETE ON Student_performance 
FOR EACH ROW 
BEGIN 
    INSERT INTO Student_performance_Deleted (
        Student_ID, Semester_Name, Paper_ID, Paper_Name, Marks, deleted_at
    ) 
    VALUES (
        :OLD.Student_ID, :OLD.Semester_Name, :OLD.Paper_ID, :OLD.Paper_Name, :OLD.Marks, SYSTIMESTAMP
    ); 
END; 
/



--before update trigger--
CREATE OR REPLACE TRIGGER before_delete_department
BEFORE DELETE ON Department_info
FOR EACH ROW
BEGIN
    -- Check if the record exists
    IF :OLD.Department_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'Department ID is required and cannot be NULL.');
    END IF;

END;
/

CREATE OR REPLACE TRIGGER before_delete_employee
BEFORE DELETE ON Employee_info
FOR EACH ROW
BEGIN
    -- Check if the Employee_ID is valid (not NULL)
    IF :OLD.Employee_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20002, 'Employee ID is required and cannot be NULL.');
    END IF;
END;
/

CREATE OR REPLACE TRIGGER before_delete_stud_counsel
BEFORE DELETE ON Student_counseling
FOR EACH ROW
BEGIN
    -- Check if the record exists 
    IF :OLD.Student_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20003, 'Student ID is required and cannot be NULL.');
    END IF;

END;
/

CREATE OR REPLACE TRIGGER before_delete_stu_perf
BEFORE DELETE ON Student_performance
FOR EACH ROW
BEGIN
    -- Check if the record exists 
    IF :OLD.Student_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20004, 'Student ID is required and cannot be NULL.');
    END IF;
END
/
