
CREATE OR REPLACE PROCEDURE delete_from_chosen_table(
    p_choice IN NUMBER,
    p_id IN VARCHAR2
) AS
    v_table_name VARCHAR2(255);
    v_column_name VARCHAR2(255);
    v_sql VARCHAR2(1000);
BEGIN
    -- Determine the table and column name based on the user's choice
    CASE p_choice
        WHEN 1 THEN
            v_table_name := 'Department_info';
            v_column_name := 'Department_ID';
        WHEN 2 THEN
            v_table_name := 'Employee_info';
            v_column_name := 'Employee_ID';
        WHEN 3 THEN
            v_table_name := 'Student_counseling';
            v_column_name := 'Student_ID';
        WHEN 4 THEN
            v_table_name := 'Student_performance';
            v_column_name := 'Student_ID';
        ELSE
            DBMS_OUTPUT.PUT_LINE('Invalid choice. Please choose a valid option (1-4).');
            RETURN;
    END CASE;

    --Savepoint before selete
    SAVEPOINT before_delete;

    -- Perform the DELETE operation
    v_sql := 'DELETE FROM ' || v_table_name || ' WHERE ' || v_column_name || ' = :1';
    EXECUTE IMMEDIATE v_sql USING p_id;

    -- Check if any rows were deleted
    IF SQL%ROWCOUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('No record found with ID ' || p_id || ' in ' || v_table_name || '. Deletion was not performed.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Record with ID ' || p_id || ' has been deleted from ' || v_table_name || '.');
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO before_delete;
        RAISE; 
END;
/





--enable on delete cascade to handle the child record deletion--

ALTER TABLE Employee_info DROP CONSTRAINT fk_Employee_Department;

ALTER TABLE Student_counseling DROP CONSTRAINT fk_Student_Admission;

ALTER TABLE Student_performance DROP CONSTRAINT fk_Student_performance_Student;


ALTER TABLE Employee_info
ADD CONSTRAINT fk_Employee_Department FOREIGN KEY (Department_ID)
REFERENCES Department_info (Department_ID) ON DELETE CASCADE;

ALTER TABLE Student_counseling
ADD CONSTRAINT fk_Student_Admission FOREIGN KEY (Department_Admission)
REFERENCES Department_info (Department_ID) ON DELETE CASCADE;

ALTER TABLE Student_performance
ADD CONSTRAINT fk_Student_performance_Student FOREIGN KEY (Student_ID)
REFERENCES Student_counseling (Student_ID) ON DELETE CASCADE;






--Execution--
--Prompt user to choose the table--
ACCEPT v_choice NUMBER PROMPT 'Choose the table to delete from: 1. Department_info, 2. Employee_info, 3. Student_counseling, 4. Student_performance: '

--Validate the choice and proceed only if it's valid--
DECLARE
    v_choice NUMBER := &v_choice;
BEGIN
    IF v_choice NOT IN (1, 2, 3, 4) THEN
        DBMS_OUTPUT.PUT_LINE('Invalid choice. Please choose a valid option (1-4).');
        RAISE_APPLICATION_ERROR(-20001, 'Invalid choice.');
    END IF;
END;
/

--If the choice is valid, prompt for the corresponding ID--
ACCEPT v_id CHAR PROMPT 'Enter the corresponding ID to delete: '

--Execute the delete procedure with the provided inputs--
DECLARE
    v_choice NUMBER := &v_choice;
    v_id VARCHAR2(255) := '&v_id';
BEGIN
    delete_from_chosen_table(p_choice => v_choice, p_id => v_id);
END;
/

